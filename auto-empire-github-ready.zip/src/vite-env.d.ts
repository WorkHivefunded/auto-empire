/// <reference types="vite/client" />
interface ImportMetaEnv {
  readonly VITE_APPWRITE_ENDPOINT: string;
  readonly VITE_APPWRITE_PROJECT_ID: string;
  readonly VITE_APPWRITE_DATABASE_ID: string;
  readonly VITE_APPWRITE_CARS_TABLE_ID: string;
  readonly VITE_APPWRITE_CAR_PHOTOS_BUCKET_ID: string;
  readonly VITE_ADMIN_EMAILS?: string;
}
interface ImportMeta { readonly env: ImportMetaEnv; }