import { Client, Account, Storage, TablesDB } from "@appwrite.io/sdk";

export const client = new Client()
  .setEndpoint(import.meta.env.VITE_APPWRITE_ENDPOINT)
  .setProject(import.meta.env.VITE_APPWRITE_PROJECT_ID);

export const account = new Account(client);
export const storage = new Storage(client);
export const tablesDB = new TablesDB(client);

export const APPWRITE = {
  databaseId: import.meta.env.VITE_APPWRITE_DATABASE_ID,
  carsTableId: import.meta.env.VITE_APPWRITE_CARS_TABLE_ID,
  photosBucketId: import.meta.env.VITE_APPWRITE_CAR_PHOTOS_BUCKET_ID,
};

export function fileUrl(fileId: string) {
  return `${APPWRITEEndpoint()}/storage/buckets/${APPWRITE.photosBucketId}/files/${fileId}/view?project=${encodeURIComponent(import.meta.env.VITE_APPWRITE_PROJECT_ID)}`;
}
function APPWRITEEndpoint() { return import.meta.env.VITE_APPWRITE_ENDPOINT; }