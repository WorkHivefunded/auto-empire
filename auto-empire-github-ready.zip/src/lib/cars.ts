import { ID, Query } from "@appwrite.io/sdk";
import { APPWRITE, storage, tablesDB } from "./appwrite";
import type { Car } from "./types";

const clean = (c: Car) => {
  const out: Record<string, unknown> = {
    name: c.name,
    brand: c.brand,
    model: c.model || "",
    year: Number(c.year || new Date().getFullYear()),
    price: Number(c.price || 0),
    fuel: c.fuel || "",
    transmission: c.transmission || "",
    bodyType: c.bodyType || "",
    city: c.city || "",
    description: c.description || "",
    photos: c.photos || [],
    featured: Boolean(c.featured),
    published: c.published !== false
  };
  return out;
};

export async function listCars(onlyPublished = true) {
  const queries = [Query.orderDesc("$createdAt"), Query.limit(100)];
  if (onlyPublished) queries.push(Query.equal("published", true));
  const res = await tablesDB.listRows({
    databaseId: APPWRITE.databaseId,
    tableId: APPWRITE.carsTableId,
    queries
  });
  return (res.rows || []) as unknown as Car[];
}

export async function getCar(id: string) {
  return await tablesDB.getRow({
    databaseId: APPWRITE.databaseId,
    tableId: APPWRITE.carsTableId,
    rowId: id
  }) as unknown as Car;
}

export async function createCar(car: Car) {
  return await tablesDB.createRow({
    databaseId: APPWRITE.databaseId,
    tableId: APPWRITE.carsTableId,
    rowId: ID.unique(),
    data: clean(car)
  });
}

export async function updateCar(id: string, car: Car) {
  return await tablesDB.updateRow({
    databaseId: APPWRITE.databaseId,
    tableId: APPWRITE.carsTableId,
    rowId: id,
    data: clean(car)
  });
}

export async function deleteCar(id: string) {
  return await tablesDB.deleteRow({
    databaseId: APPWRITE.databaseId,
    tableId: APPWRITE.carsTableId,
    rowId: id
  });
}

export async function uploadPhotos(files: File[]) {
  const ids: string[] = [];
  for (const file of files) {
    const result = await storage.createFile({
      bucketId: APPWRITE.photosBucketId,
      fileId: ID.unique(),
      file
    });
    ids.push(result.$id);
  }
  return ids;
}