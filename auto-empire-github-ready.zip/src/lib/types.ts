export type Car = {
  $id?: string;
  name: string;
  brand: string;
  model?: string;
  year?: number;
  price?: number;
  fuel?: string;
  transmission?: string;
  bodyType?: string;
  city?: string;
  description?: string;
  photos?: string[];
  featured?: boolean;
  published?: boolean;
  createdAt?: string;
  [key: string]: unknown;
};

export type UserSession = {
  $id: string;
  name?: string;
  email?: string;
};