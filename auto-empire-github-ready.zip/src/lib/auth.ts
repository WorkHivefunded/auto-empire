import { account } from "./appwrite";
import type { UserSession } from "./types";

export async function getSession(): Promise<UserSession | null> {
  try { return await account.get() as unknown as UserSession; }
  catch { return null; }
}

export async function login(email: string, password: string) {
  await account.createEmailPasswordSession({ email, password });
  return getSession();
}

export async function register(name: string, email: string, password: string) {
  await account.create({ userId: "unique()", email, password, name });
  await login(email, password);
  return getSession();
}

export async function logout() {
  await account.deleteSession({ sessionId: "current" });
}

export function isAdmin(email?: string) {
  const raw = import.meta.env.VITE_ADMIN_EMAILS || "";
  const list = raw.split(",").map(x => x.trim().toLowerCase()).filter(Boolean);
  return !!email && list.includes(email.toLowerCase());
}