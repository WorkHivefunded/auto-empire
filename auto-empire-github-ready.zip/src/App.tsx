import { createContext, useContext, useEffect, useState } from "react";
import { Routes, Route, Navigate, Link, useNavigate, useParams } from "react-router-dom";
import { account } from "./lib/appwrite";
import { getSession, isAdmin, login, logout as doLogout, register } from "./lib/auth";
import { createCar, deleteCar, getCar, listCars, updateCar, uploadPhotos } from "./lib/cars";
import type { Car, UserSession } from "./lib/types";
import Layout from "./components/Layout";
import CarCard from "./components/CarCard";

const AuthContext = createContext<any>(null);
export const useAuth = () => useContext(AuthContext);

function Home() {
  const [cars,setCars]=useState<Car[]>([]);
  useEffect(()=>{listCars(true).then(setCars).catch(()=>setCars([]))},[]);
  return <div>
    <section className="hero"><div className="hero-copy"><p className="eyebrow">INDIA'S PREMIUM CAR MARKETPLACE</p><h1>Find the car<br/><i>you deserve.</i></h1><p>Discover premium new and pre-owned cars with transparent details and a simple buying journey.</p><div className="hero-actions"><Link className="btn primary" to="/cars">Explore Cars</Link><Link className="btn ghost" to="/test-drive">Book a Test Drive</Link></div></div><div className="hero-art"><div className="car-silhouette">AUTO<br/>EMPIRE</div></div></section>
    <section className="section"><div className="section-head"><div><p className="eyebrow">CURATED FOR YOU</p><h2>Featured cars</h2></div><Link to="/cars">View all →</Link></div><div className="grid">{cars.filter(c=>c.featured).slice(0,6).map(c=><CarCard key={c.$id} car={c}/>)}</div>{!cars.length&&<div className="empty">No published cars yet. Add cars from the Admin panel.</div>}</section>
  </div>;
}

function Cars() {
  const [cars,setCars]=useState<Car[]>([]); const [q,setQ]=useState(""); const [brand,setBrand]=useState("");
  useEffect(()=>{listCars(true).then(setCars).catch(()=>setCars([]))},[]);
  const brands=[...new Set(cars.map(c=>c.brand).filter(Boolean))];
  const filtered=cars.filter(c=>(!q||`${c.name} ${c.brand} ${c.model}`.toLowerCase().includes(q.toLowerCase()))&&(!brand||c.brand===brand));
  return <div className="page"><div className="page-head"><p className="eyebrow">INVENTORY</p><h1>All cars</h1></div><div className="filters"><input placeholder="Search cars..." value={q} onChange={e=>setQ(e.target.value)}/><select value={brand} onChange={e=>setBrand(e.target.value)}><option value="">All brands</option>{brands.map(b=><option key={b}>{b}</option>)}</select></div><div className="grid">{filtered.map(c=><CarCard key={c.$id} car={c}/> )}</div>{!filtered.length&&<div className="empty">No matching cars found.</div>}</div>;
}

function Detail() {
  const {id}=useParams(); const [car,setCar]=useState<Car|null>(null); const [err,setErr]=useState("");
  useEffect(()=>{if(id)getCar(id).then(setCar).catch(e=>setErr(e.message||"Unable to load car"))},[id]);
  if(err)return <div className="page"><div className="error">{err}</div></div>;
  if(!car)return <div className="page"><div className="loading">Loading...</div></div>;
  return <div className="page"><Link to="/cars">← Back to cars</Link><div className="detail"><div className="gallery">{(car.photos||[]).map((p,i)=><img key={p} src={String(p).startsWith("http")?String(p):requireFile(p)} alt={`${car.name} ${i+1}`}/>)}</div><div className="detail-copy"><p className="eyebrow">{car.brand}</p><h1>{car.name}</h1><div className="price">{car.price?`₹${Number(car.price).toLocaleString("en-IN")}`:"Price on request"}</div><p>{car.description}</p><div className="spec-grid"><b>Year<span>{car.year||"—"}</span></b><b>Fuel<span>{car.fuel||"—"}</span></b><b>Transmission<span>{car.transmission||"—"}</span></b><b>Body<span>{car.bodyType||"—"}</span></b></div><Link className="btn primary" to={`/test-drive?car=${encodeURIComponent(car.name)}`}>Book Test Drive</Link></div></div></div>;
}
function requireFile(id: unknown){ return `${import.meta.env.VITE_APPWRITE_ENDPOINT}/storage/buckets/${import.meta.env.VITE_APPWRITE_CAR_PHOTOS_BUCKET_ID}/files/${id}/view?project=${import.meta.env.VITE_APPWRITE_PROJECT_ID}`; }

function Brands(){return <div className="page"><p className="eyebrow">DISCOVER</p><h1>Brands</h1><p className="lead">Browse our curated collection by manufacturer.</p><Link className="btn primary" to="/cars">Browse inventory</Link></div>}
function Compare(){return <div className="page"><p className="eyebrow">COMPARE</p><h1>Compare cars</h1><p className="lead">Add cars from the inventory to compare specifications.</p><Link className="btn primary" to="/cars">Choose cars</Link></div>}
function Wishlist(){const [ids,setIds]=useState<string[]>(()=>JSON.parse(localStorage.getItem("ae-wishlist")||"[]")); const [cars,setCars]=useState<Car[]>([]); useEffect(()=>{listCars(true).then(a=>setCars(a.filter(c=>ids.includes(c.$id||"")))).catch(()=>{})},[ids]); return <div className="page"><p className="eyebrow">SAVED</p><h1>Wishlist</h1><div className="grid">{cars.map(c=><CarCard key={c.$id} car={c}/>)}</div>{!cars.length&&<div className="empty">Your wishlist is empty.</div>}</div>}

function AuthPage({mode}:{mode:"login"|"register"}) {
  const {refresh}=useAuth(); const nav=useNavigate(); const [name,setName]=useState(""); const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [err,setErr]=useState(""); const [busy,setBusy]=useState(false);
  async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setErr("");try{if(mode==="login")await login(email,password);else await register(name,email,password);await refresh();nav("/")}catch(x:any){setErr(x?.message||"Authentication failed")}finally{setBusy(false)}}
  return <div className="auth"><form className="panel" onSubmit={submit}><p className="eyebrow">{mode==="login"?"WELCOME BACK":"JOIN AUTO EMPIRE"}</p><h1>{mode==="login"?"Sign in":"Create account"}</h1>{mode==="register"&&<input placeholder="Full name" value={name} onChange={e=>setName(e.target.value)} required/>}<input type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required/><input type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} required minLength={8}/>{err&&<div className="error">{err}</div>}<button className="btn primary" disabled={busy}>{busy?"Please wait...":mode==="login"?"Sign in":"Create account"}</button><p>{mode==="login"?<>New here? <Link to="/register">Create an account</Link></>:<>Already registered? <Link to="/login">Sign in</Link></>}</p></form></div>;
}

function SimplePage({title,eyebrow,body}:{title:string,eyebrow:string,body:string}){return <div className="page narrow"><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p className="lead">{body}</p><Link className="btn primary" to="/cars">Explore cars</Link></div>}

function Admin() {
  const {user,admin}=useAuth(); const [cars,setCars]=useState<Car[]>([]); const [editing,setEditing]=useState<Car|null>(null); const [msg,setMsg]=useState("");
  const empty:Car={name:"",brand:"",model:"",year:new Date().getFullYear(),price:0,fuel:"Petrol",transmission:"Automatic",bodyType:"SUV",city:"",description:"",photos:[],featured:false,published:true};
  async function reload(){try{setCars(await listCars(false))}catch(e:any){setMsg(e.message||"Could not load cars")}}
  useEffect(()=>{reload()},[]);
  if(!admin)return <Navigate to="/login" replace/>;
  async function save(data:Car,files:FileList|null){try{let photos=data.photos||[];if(files?.length)photos=[...photos,...await uploadPhotos(Array.from(files))];const final={...data,photos};if(data.$id)await updateCar(data.$id,final);else await createCar(final);setEditing(null);setMsg("Saved successfully");await reload()}catch(e:any){setMsg(e.message||"Save failed")}}
  return <div className="page"><div className="admin-top"><div><p className="eyebrow">PROTECTED ADMIN</p><h1>Dashboard</h1><p>{user?.email}</p></div><button className="btn primary" onClick={()=>setEditing(empty)}>+ Add car</button></div>{msg&&<div className="notice">{msg}</div>}{editing&&<CarForm car={editing} onCancel={()=>setEditing(null)} onSave={save}/>}<div className="admin-table">{cars.map(c=><div className="admin-row" key={c.$id}><div><b>{c.name}</b><span>{c.brand} · {c.city||"India"} · {c.published?"Published":"Draft"}</span></div><div className="row-actions"><button onClick={()=>setEditing(c)}>Edit</button><button onClick={async()=>{if(confirm("Delete this car?")){await deleteCar(c.$id!);reload()}}}>Delete</button></div></div>)}</div></div>;
}

function CarForm({car,onCancel,onSave}:{car:Car,onCancel:()=>void,onSave:(c:Car,f:FileList|null)=>void}) {
  const [d,setD]=useState<Car>(car); const [files,setFiles]=useState<FileList|null>(null);
  const set=(k:keyof Car,v:any)=>setD(x=>({...x,[k]:v}));
  return <div className="panel form-panel"><h2>{d.$id?"Edit car":"Add car"}</h2><div className="form-grid"><input placeholder="Car name" value={d.name} onChange={e=>set("name",e.target.value)} required/><input placeholder="Brand" value={d.brand} onChange={e=>set("brand",e.target.value)} required/><input placeholder="Model" value={d.model as string} onChange={e=>set("model",e.target.value)}/><input type="number" placeholder="Year" value={Number(d.year||"")} onChange={e=>set("year",Number(e.target.value))}/><input type="number" placeholder="Price" value={Number(d.price||"")} onChange={e=>set("price",Number(e.target.value))}/><input placeholder="City" value={d.city as string} onChange={e=>set("city",e.target.value)}/><input placeholder="Fuel" value={d.fuel as string} onChange={e=>set("fuel",e.target.value)}/><input placeholder="Transmission" value={d.transmission as string} onChange={e=>set("transmission",e.target.value)}/><input placeholder="Body type" value={d.bodyType as string} onChange={e=>set("bodyType",e.target.value)}/><input type="file" multiple accept="image/*" onChange={e=>setFiles(e.target.files)}/></div><textarea placeholder="Description" value={d.description as string} onChange={e=>set("description",e.target.value)}/><label><input type="checkbox" checked={Boolean(d.featured)} onChange={e=>set("featured",e.target.checked)}/> Featured</label><label><input type="checkbox" checked={d.published!==false} onChange={e=>set("published",e.target.checked)}/> Published</label><div className="row-actions"><button onClick={onCancel}>Cancel</button><button className="btn primary" onClick={()=>onSave(d,files)}>Save & upload</button></div></div>;
}

export default function App(){
  const [user,setUser]=useState<UserSession|null>(null); const [loading,setLoading]=useState(true);
  const refresh=async()=>setUser(await getSession());
  useEffect(()=>{refresh().finally(()=>setLoading(false))},[]);
  const admin=isAdmin(user?.email);
  const value={user,admin,refresh,logout:async()=>{await doLogout();setUser(null)}};
  if(loading)return <div className="loading full">Loading Auto Empire...</div>;
  return <AuthContext.Provider value={value}><Layout><Routes>
    <Route path="/" element={<Home/>}/><Route path="/cars" element={<Cars/>}/><Route path="/cars/:id" element={<Detail/>}/>
    <Route path="/brands" element={<Brands/>}/><Route path="/compare" element={<Compare/>}/><Route path="/wishlist" element={<Wishlist/>}/>
    <Route path="/contact" element={<SimplePage eyebrow="GET IN TOUCH" title="Contact Auto Empire" body="Have a question about a car, enquiry, finance or delivery? Our team is ready to help."/>}/>
    <Route path="/test-drive" element={<SimplePage eyebrow="EXPERIENCE IT" title="Book a test drive" body="Choose a car and our team will contact you to arrange a convenient test drive."/>}/>
    <Route path="/login" element={<AuthPage mode="login"/>}/><Route path="/register" element={<AuthPage mode="register"/>}/>
    <Route path="/admin" element={<Admin/>}/><Route path="*" element={<Navigate to="/" replace/>}/>
  </Routes></Layout></AuthContext.Provider>;
}