import { Link, NavLink, useNavigate } from "react-router-dom";
import { Heart, Search, Shield, User } from "lucide-react";
import { useAuth } from "../App";

export default function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout, admin } = useAuth();
  const navigate = useNavigate();
  return <div className="app-shell">
    <header className="header">
      <Link className="logo" to="/"><span>AE</span> AUTO EMPIRE</Link>
      <nav>
        <NavLink to="/cars">Cars</NavLink>
        <NavLink to="/brands">Brands</NavLink>
        <NavLink to="/compare">Compare</NavLink>
        <NavLink to="/wishlist">Wishlist</NavLink>
        <NavLink to="/contact">Contact</NavLink>
        {admin && <NavLink to="/admin"><Shield size={15}/> Admin</NavLink>}
      </nav>
      <div className="header-actions">
        <Link to="/cars" aria-label="Search"><Search size={18}/></Link>
        {user ? <button className="icon-btn" onClick={async()=>{await logout(); navigate("/");}} title="Logout"><User size={18}/></button> : <Link to="/login"><User size={18}/></Link>}
      </div>
    </header>
    <main>{children}</main>
    <footer className="footer">
      <div><b>AUTO EMPIRE</b><p>Premium Indian car marketplace.</p></div>
      <div><Link to="/contact">Contact</Link><Link to="/test-drive">Test Drive</Link><Link to="/login">Account</Link></div>
      <small>© {new Date().getFullYear()} Auto Empire</small>
    </footer>
  </div>;
}