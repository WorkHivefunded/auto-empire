import { Link } from "react-router-dom";
import { Heart } from "lucide-react";
import type { Car } from "../lib/types";
import { fileUrl } from "../lib/appwrite";

export default function CarCard({ car }: { car: Car }) {
  const first = Array.isArray(car.photos) && car.photos.length ? fileUrl(String(car.photos[0])) : "";
  return <article className="car-card">
    <Link to={`/cars/${car.$id}`} className="car-image">
      {first ? <img src={first} alt={car.name}/> : <div className="image-placeholder">AUTO EMPIRE</div>}
      {car.featured && <span className="badge">FEATURED</span>}
      <button type="button" className="heart" onClick={e=>{e.preventDefault(); e.stopPropagation(); const k="ae-wishlist"; const a=JSON.parse(localStorage.getItem(k)||"[]"); const id=car.$id; const next=a.includes(id)?a.filter((x:string)=>x!==id):[...a,id]; localStorage.setItem(k,JSON.stringify(next));}}><Heart size={18}/></button>
    </Link>
    <div className="car-info">
      <div className="muted">{car.brand} {car.model || ""}</div>
      <h3>{car.name}</h3>
      <div className="specs"><span>{car.year}</span><span>{car.fuel}</span><span>{car.transmission}</span></div>
      <strong>{car.price ? `₹${Number(car.price).toLocaleString("en-IN")}` : "Price on request"}</strong>
    </div>
  </article>;
}