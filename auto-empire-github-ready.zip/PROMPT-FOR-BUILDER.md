# Master build prompt

Build and polish this repository as **Auto Empire**, a premium Indian car marketplace.

Non-negotiable backend:
- Keep Appwrite. Do not replace it with Supabase, Firebase, mock APIs, local JSON, or another backend.
- Endpoint: https://fra.cloud.appwrite.io/v1
- Project ID: 6a7ad09c002b3c4f35d2
- Database ID: 6a7ad20d00262e017803
- Cars table ID: cars
- Storage bucket ID: car-photos
- Use Appwrite Account, TablesDB, Storage, Query and ID.

Customer routes:
- `/`
- `/cars`
- `/cars/:id`
- `/brands`
- `/compare`
- `/wishlist`
- `/login`
- `/register`
- `/test-drive`
- `/contact`
- `/admin`

Required behavior:
- No blank screens.
- Loading, empty and error states everywhere data is remote.
- Responsive mobile/tablet/desktop UI.
- Real Appwrite car reads.
- Real Appwrite image uploads.
- Save uploaded File IDs in the car row `photos` field.
- Customer can search/filter cars.
- Car detail pages show real photos and specifications.
- Wishlist persists in browser storage.
- Auth uses Appwrite email/password.
- Admin page is protected and only allow-listed admin emails can enter.
- Admin CRUD: add, edit, delete, publish/draft, featured.
- Never remove the Appwrite configuration.
- Do not replace working code with mock data.

Design:
- Premium automotive aesthetic.
- Dark, minimal, high-end editorial UI.
- Strong typography, generous spacing, subtle borders.
- Fast mobile experience.
- Clear CTAs for Explore Cars and Book Test Drive.

Before finishing:
- Run the production build.
- Fix all TypeScript/build errors.
- Verify every route.
- Verify Appwrite calls use the configured IDs.
- Verify multiple-image upload stores File IDs.
- Do not leave TODO placeholders for core functionality.