# Auto Empire

Premium Indian car marketplace with a customer website and protected admin panel.

## Appwrite (already configured)

- Endpoint: `https://fra.cloud.appwrite.io/v1`
- Project: `6a7ad09c002b3c4f35d2`
- Database: `6a7ad20d00262e017803`
- Cars table: `cars`
- Storage bucket: `car-photos`

Copy `.env.example` to `.env` before running.

## Run

```bash
npm install
npm run dev
```

Production build:

```bash
npm run build
```

## Admin access

Set `VITE_ADMIN_EMAILS` in `.env` to the Appwrite account email(s) that may open `/admin`.

Example:

```env
VITE_ADMIN_EMAILS=your-admin-email@example.com
```

The admin dashboard supports:
- create/edit/delete cars
- publish/draft
- featured toggle
- multiple image uploads to Appwrite Storage
- saved Appwrite File IDs in the `photos` field

## Important Appwrite permissions

For the frontend to work, configure Appwrite permissions appropriately:

1. Authentication: Email/password enabled.
2. `cars` table: public read access for published inventory, and authenticated/admin write access as required by your security model.
3. `car-photos` bucket: public read access and authenticated/admin create access.
4. The `cars` table must contain the fields used by this starter:
   `name`, `brand`, `model`, `year`, `price`, `fuel`, `transmission`, `bodyType`, `city`, `description`, `photos`, `featured`, `published`.

For a production system, enforce admin permissions server-side (not only with a client-side email allow-list).